# Arduino Engineering MCP — v1.2

AEMCP v1.2 fixes the missing `arduino-cli` runtime dependency for native Render deployments.

## What changed

- `npm run setup:arduino` installs Arduino CLI inside the project directory, so it is available to the running Render service.
- The setup script installs the Arduino AVR core for Uno, Nano, Mega 2560, Leonardo and Micro.
- The MCP server calls the project-local Arduino CLI and its project-local configuration instead of assuming `arduino-cli` is globally installed.
- New MCP tool `install_arduino_platform` can install `esp32:esp32` when requested. ESP32 is installed on demand because its core is large and takes additional build time and disk space.
- Health endpoint reports version 1.2.0 and 14 tools.

## Update an existing native Render service

1. Replace the source ZIP in your GitHub repository with this v1.2 ZIP (keep the ZIP at the repository location expected by your current workflow).
2. In Render, open the existing service → **Settings** → **Build & Deploy**.
3. Set **Build Command** to:

   ```bash
   npm install --omit=dev && npm run setup:arduino
   ```

   If your current Render service extracts the source ZIP during its build, keep that extraction step and run the setup command from the extracted source directory, for example:

   ```bash
   unzip -o Arduino-Engineering-MCP-Source-only-1.zip -d aemcp-source && cd aemcp-source && npm install --omit=dev && npm run setup:arduino
   ```

4. Keep **Start Command** as:

   ```bash
   cd aemcp-source && npm start
   ```

   If you deployed the source files directly at the repository root instead, use `npm start`.
5. Save and deploy. The first build takes longer because it downloads Arduino CLI and the AVR board core.
6. Check `/health`. It should report version `1.2.0` and `14` tools.

The Arduino CLI and AVR core are installed under the project directory (`.tools/` and `.arduino/`), not globally. This is intended for a native Node Render service.

## ESP32

After deployment, ask Claude to use `install_arduino_platform` with `platform` set to `esp32:esp32`. This installs Espressif's official Arduino-ESP32 core on the server. It may take several minutes and use significant disk space. Then retry ESP32 compilation.

## Local checks

```bash
npm install
npm run check
npm test
npm run setup:arduino
```

## Security and limitations

- Set a strong private `MCP_API_TOKEN` in Render. Do not paste it into chats, source files or GitHub.
- Compilation is compile-only; it never uploads firmware to a physical board.
- A cloud Render service cannot access an Arduino plugged into your phone's OTG port. Serial tools only see ports attached to the server host.
- Static analysis cannot certify wiring, voltage, current or electrical safety.
- Wokwi still requires its own CLI, token and a project directory available on the server.
- Free hosting instances may sleep and cause cold-start delays.
