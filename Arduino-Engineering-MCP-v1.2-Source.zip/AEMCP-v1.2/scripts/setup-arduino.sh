#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS_DIR="$ROOT/.tools"
ARDUINO_DIR="$ROOT/.arduino"
CONFIG_FILE="$ARDUINO_DIR/arduino-cli.yaml"
CLI="$TOOLS_DIR/arduino-cli"

mkdir -p "$TOOLS_DIR" "$ARDUINO_DIR/data" "$ARDUINO_DIR/downloads" "$ARDUINO_DIR/user"

if [[ ! -x "$CLI" ]]; then
  echo "Installing Arduino CLI into project-local .tools directory..."
  command -v curl >/dev/null 2>&1 || { echo "curl is required to install Arduino CLI" >&2; exit 1; }
  curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh | BINDIR="$TOOLS_DIR" sh
fi

if [[ ! -f "$CONFIG_FILE" ]]; then
  "$CLI" config init --dest-dir "$ARDUINO_DIR"
fi

"$CLI" --config-file "$CONFIG_FILE" config set directories.data "$ARDUINO_DIR/data"
"$CLI" --config-file "$CONFIG_FILE" config set directories.downloads "$ARDUINO_DIR/downloads"
"$CLI" --config-file "$CONFIG_FILE" config set directories.user "$ARDUINO_DIR/user"
"$CLI" --config-file "$CONFIG_FILE" core update-index
"$CLI" --config-file "$CONFIG_FILE" core install arduino:avr

printf '\nArduino CLI setup complete. AVR platform is installed.\n'
printf 'ESP32 can be installed later using the install_arduino_platform MCP tool with platform esp32:esp32.\n'
