import express from "express";
import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import fs from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { SerialPort } from "serialport";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const execFileAsync = promisify(execFile);
const app = express();
app.use(express.json({ limit: "256kb" }));

const PORT = Number(process.env.PORT || 3000);
const TOKEN = process.env.MCP_API_TOKEN || "";
const ARDUINO_CLI = process.env.ARDUINO_CLI_PATH || path.join(process.cwd(), ".tools", "arduino-cli");
const ARDUINO_CLI_CONFIG = process.env.ARDUINO_CLI_CONFIG || path.join(process.cwd(), ".arduino", "arduino-cli.yaml");
const MAX_CODE = 60000;
const MAX_LOG = 30000;
const MAX_SERIAL_SESSIONS = 4;
const serialSessions = new Map();

const BOARDS = {
  "arduino:avr:uno": { label: "Arduino Uno", digital: 14, analog: 6, pwm: [3,5,6,9,10,11] },
  "arduino:avr:nano": { label: "Arduino Nano", digital: 14, analog: 8, pwm: [3,5,6,9,10,11] },
  "arduino:avr:mega": { label: "Arduino Mega 2560", digital: 54, analog: 16, pwm: [2,3,4,5,6,7,8,9,10,11,12,13,44,45,46] },
  "arduino:avr:leonardo": { label: "Arduino Leonardo", digital: 20, analog: 12, pwm: [3,5,6,9,10,11,13] },
  "arduino:avr:micro": { label: "Arduino Micro", digital: 20, analog: 12, pwm: [3,5,6,9,10,11,13] },
  "esp32:esp32:esp32": { label: "ESP32 Dev Module", digital: 40, analog: 18, pwm: [] }
};

function authorized(req) {
  if (!TOKEN) return process.env.NODE_ENV !== "production";
  const h = req.get("authorization") || "";
  const supplied = h.startsWith("Bearer ") ? h.slice(7) : "";
  const a = Buffer.from(supplied), b = Buffer.from(TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const result = value => ({ content: [{ type: "text", text: typeof value === "string" ? value : JSON.stringify(value, null, 2) }] });
const stripComments = s => s.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");

function analyze(code) {
  const c = stripComments(code), errors = [], warnings = [];
  const add = (a, s) => { if (!a.includes(s)) a.push(s); };
  if (!/\bvoid\s+setup\s*\(\s*(?:void)?\s*\)/.test(c)) add(errors, "Missing void setup().");
  if (!/\bvoid\s+loop\s*\(\s*(?:void)?\s*\)/.test(c)) add(errors, "Missing void loop().");

  for (const [l, r, label] of [["{","}","braces"],["(",")","parentheses"],["[","]","brackets"]]) {
    const n1 = [...c].filter(x => x === l).length, n2 = [...c].filter(x => x === r).length;
    if (n1 !== n2) add(errors, `Unbalanced ${label}: ${n1} opening, ${n2} closing.`);
  }

  const outputPins = new Set([...c.matchAll(/pinMode\s*\(\s*(\d+)\s*,\s*OUTPUT\s*\)/g)].map(m => +m[1]));
  for (const m of c.matchAll(/digitalWrite\s*\(\s*(\d+)\s*,/g)) {
    const p = +m[1];
    if (!outputPins.has(p)) add(warnings, `digitalWrite() uses pin ${p}, but pinMode(${p}, OUTPUT) was not found.`);
  }

  if (/\bString\s+\w+/.test(c)) add(warnings, "Arduino String objects found. Repeated dynamic allocation can fragment memory on small AVR boards.");
  if (/\bdelay\s*\(\s*\d{4,}\s*\)/.test(c)) add(warnings, "Long delay() found. Consider millis() for non-blocking behaviour.");
  if (/while\s*\(\s*!\s*(?:Serial|digitalRead)/.test(c)) add(warnings, "Potentially indefinite blocking while-loop found.");
  if (/analogWrite\s*\(\s*(\d+)\s*,/g.test(c)) {
    const pins = [...c.matchAll(/analogWrite\s*\(\s*(\d+)\s*,/g)].map(m => +m[1]);
    warnings.push(`analogWrite() used on pin(s) ${[...new Set(pins)].join(", ")}; confirm PWM support for the selected board.`);
  }

  const pins = [...new Set([...c.matchAll(/(?:pinMode|digitalWrite|digitalRead|analogRead|analogWrite)\s*\(\s*(\d+)/g)].map(m => +m[1]))].sort((a,b)=>a-b);
  const includes = [...c.matchAll(/^\s*#include\s*[<"]([^>"]+)[>"]/gm)].map(m => m[1]);
  return {
    status: errors.length ? "issues_found" : "basic_checks_passed",
    errors, warnings, detectedPins: pins, includes,
    lineCount: code.split(/\r?\n/).length,
    note: "Static analysis is advisory. It cannot prove compilation, electrical safety, wiring correctness, or runtime behaviour."
  };
}

function wiringCheck(board, components) {
  const b = BOARDS[board];
  if (!b) return { valid: false, errors: ["Unsupported board."] };
  const errors = [], warnings = [], occupied = new Map();
  for (const comp of components) {
    for (const p of comp.pins) {
      if (["digital","analog"].includes(p.kind)) {
        const max = p.kind === "digital" ? b.digital : b.analog;
        if (p.pin < 0 || p.pin >= max) errors.push(`${comp.name}: ${p.kind} pin ${p.pin} is outside board range.`);
        const key = `${p.kind}:${p.pin}`;
        if (occupied.has(key) && !p.shared && !occupied.get(key).shared)
          errors.push(`Possible conflict on ${key}: ${occupied.get(key).name} and ${comp.name}.`);
        else if (!occupied.has(key)) occupied.set(key, { name: comp.name, shared: !!p.shared });
        if (p.pwm && b.pwm.length && !b.pwm.includes(p.pin))
          warnings.push(`${comp.name}: pin ${p.pin} is not a known PWM pin for ${b.label}.`);
      }
    }
  }
  warnings.push("Declared-pin validation only; it cannot inspect actual wires, voltage, current, or component datasheets.");
  return { valid: errors.length === 0, board: b.label, errors, warnings };
}

async function run(cmd, args, timeout = 90000) {
  return execFileAsync(cmd, args, { timeout, maxBuffer: 2 * 1024 * 1024 });
}

async function runArduino(args, timeout = 90000) {
  return run(ARDUINO_CLI, ["--config-file", ARDUINO_CLI_CONFIG, ...args], timeout);
}

function buildMcp() {
  const mcp = new McpServer({ name: "arduino-engineering-mcp", version: "1.0.0" });

  mcp.tool("analyze_arduino_sketch",
    "Static-check Arduino C++ for structure, likely pin setup issues, blocking delays, includes and common AVR memory concerns.",
    { code: z.string().min(1).max(MAX_CODE) },
    async ({code}) => result(analyze(code)));

  mcp.tool("validate_arduino_wiring",
    "Validate a declared pin map for an Arduino or ESP32 board. Does not verify real wiring or electrical safety.",
    { board: z.enum(Object.keys(BOARDS)), components: z.array(z.object({
      name: z.string().min(1),
      pins: z.array(z.object({
        pin: z.number().int(),
        kind: z.enum(["digital","analog","power","ground","i2c","spi","uart","other"]),
        pwm: z.boolean().optional(), shared: z.boolean().optional()
      }))
    })).max(100) },
    async ({board,components}) => result(wiringCheck(board,components)));

  mcp.tool("list_supported_boards",
    "List board FQBNs configured for AEMCP.",
    {},
    async () => result(Object.entries(BOARDS).map(([id,b])=>`${b.label}: ${id}`).join("\n")));

  mcp.tool("compile_arduino_sketch",
    "Compile-only Arduino CLI test. Never uploads firmware. Supports configured AVR boards and ESP32 if the ESP32 core is installed.",
    { code: z.string().min(1).max(MAX_CODE), board: z.enum(Object.keys(BOARDS)) },
    async ({code,board}) => {
      const root = await fs.mkdtemp(path.join(os.tmpdir(),"aemcp-"));
      const dir = path.join(root,"Sketch");
      await fs.mkdir(dir);
      await fs.writeFile(path.join(dir,"Sketch.ino"),code);
      try {
        const {stdout,stderr} = await runArduino(["compile","--fqbn",board,dir]);
        return result({success:true,board,message:"Compilation succeeded; no upload was performed.",stdout:stdout.slice(-12000),stderr:stderr.slice(-12000)});
      } catch(e) {
        return result({success:false,board,message:"Compilation failed or timed out.",exitCode:e.code??null,stdout:String(e.stdout||"").slice(-12000),stderr:String(e.stderr||e.message||"").slice(-12000)});
      } finally { await fs.rm(root,{recursive:true,force:true}); }
    });

  mcp.tool("install_arduino_library",
    "Install a named Arduino library using Arduino CLI. Only call when the user requests the dependency or approves installation.",
    { library: z.string().min(1).max(120).regex(/^[a-zA-Z0-9 _+.-]+$/) },
    async ({library}) => {
      try {
        const {stdout,stderr} = await runArduino(["lib","install",library],120000);
        return result({success:true,library,stdout,stderr});
      } catch(e) {
        return result({success:false,library,error:String(e.stderr||e.message||"Library installation failed.")});
      }
    });

  mcp.tool("list_installed_arduino_libraries",
    "List libraries installed in the Arduino CLI environment.",
    {},
    async () => {
      try { const {stdout} = await runArduino(["lib","list"]); return result(stdout); }
      catch(e) { return result({success:false,error:String(e.message)}); }
    });

  mcp.tool("install_arduino_platform",
    "Install a supported Arduino board platform on this server. ESP32 installation is large and may take several minutes. Only installs the platform explicitly requested.",
    { platform: z.enum(["arduino:avr", "esp32:esp32"]) },
    async ({platform}) => {
      try {
        if (platform === "esp32:esp32") {
          await runArduino(["config", "add", "board_manager.additional_urls", "https://espressif.github.io/arduino-esp32/package_esp32_index.json"]);
          await runArduino(["core", "update-index"], 180000);
        }
        const {stdout,stderr} = await runArduino(["core", "install", platform], 600000);
        return result({success:true,platform,message:"Board platform installed.",stdout:stdout.slice(-10000),stderr:stderr.slice(-10000)});
      } catch(e) {
        return result({success:false,platform,error:String(e.stderr||e.message||"Platform installation failed.").slice(-10000)});
      }
    });

  mcp.tool("run_wokwi_simulation",
    "Run a Wokwi CLI simulation for a project directory that exists on this server. Requires WOKWI_CLI to be installed and WOKWI_CLI_TOKEN configured. This server does not fabricate simulation results.",
    { projectPath: z.string().min(1).max(300) },
    async ({projectPath}) => {
      const root = path.resolve(process.env.AEMCP_PROJECT_ROOT || "/workspace");
      const target = path.resolve(projectPath);
      if (!(target === root || target.startsWith(root + path.sep)))
        return result({success:false,error:"Project path must be inside AEMCP_PROJECT_ROOT."});
      try {
        const {stdout,stderr} = await run("wokwi-cli",["--project-dir",target],180000);
        return result({success:true,stdout:stdout.slice(-12000),stderr:stderr.slice(-12000)});
      } catch(e) {
        return result({success:false,error:String(e.stderr||e.message||"Wokwi CLI failed."),stdout:String(e.stdout||"").slice(-8000)});
      }
    });

  mcp.tool("analyze_serial_log",
    "Analyze pasted Arduino Serial Monitor output for common crash, connection, sensor and timeout patterns.",
    { log: z.string().min(1).max(MAX_LOG), baudRate: z.number().int().positive().optional() },
    async ({log,baudRate}) => {
      const rules = [
        [/brownout|brown.?out/i,"Possible brownout or unstable power."],
        [/rst:|panic|abort|Guru Meditation/i,"ESP32 reset, panic, or exception message detected."],
        [/timed?\s*out|timeout|no response/i,"Timeout or missing-response pattern detected."],
        [/nan\b|inf\b|overflow/i,"Invalid numeric value or overflow pattern detected."],
        [/failed to connect|connection refused|not connected/i,"Connection failure pattern detected."],
        [/i2c.*(error|nack)|nack.*i2c/i,"I2C communication error pattern detected."],
        [/sensor.*(fail|error)|read.*failed/i,"Sensor read failure pattern detected."],
        [/out of memory|heap.*low|allocation failed/i,"Memory pressure or allocation failure pattern detected."]
      ];
      const findings = rules.filter(([re])=>re.test(log)).map(([,message])=>message);
      return result({baudRate:baudRate??null,findings,summary:findings.length? "Potential issues found in serial output." : "No known error patterns detected.",note:"Log analysis is heuristic and may miss issues or flag benign messages."});
    });

  mcp.tool("list_serial_ports",
    "List serial devices visible to the machine running this MCP server. For physical board access, run the server on the computer connected to the board and pass through its USB device.",
    {},
    async () => {
      try { return result(await SerialPort.list()); }
      catch(e) { return result({success:false,error:String(e.message)}); }
    });

  mcp.tool("serial_open",
    "Open a serial port on the machine running this MCP server. Use only with the user's selected port and baud rate.",
    { path: z.string().min(1).max(200), baudRate: z.number().int().min(300).max(2000000) },
    async ({path:portPath,baudRate}) => {
      if (serialSessions.size >= MAX_SERIAL_SESSIONS) return result({success:false,error:"Serial session limit reached."});
      if (serialSessions.has(portPath)) return result({success:false,error:"This port is already open."});
      const port = new SerialPort({path:portPath,baudRate,autoOpen:false});
      try {
        await new Promise((resolve,reject)=>port.open(err=>err?reject(err):resolve()));
        let buffer = "";
        port.on("data",data=>{ buffer=(buffer+data.toString("utf8")).slice(-12000); });
        serialSessions.set(portPath,{port,getBuffer:()=>buffer,clear:()=>{buffer="";}});
        return result({success:true,path:portPath,baudRate,message:"Serial port opened. Use serial_read and serial_send."});
      } catch(e) { return result({success:false,error:String(e.message)}); }
    });

  mcp.tool("serial_read",
    "Read and clear buffered text from an open serial session.",
    { path: z.string().min(1).max(200) },
    async ({path:portPath}) => {
      const s=serialSessions.get(portPath);
      if(!s) return result({success:false,error:"Port is not open."});
      const data=s.getBuffer(); s.clear();
      return result({success:true,path:portPath,data});
    });

  mcp.tool("serial_send",
    "Send a text command to an already-open serial session. Use only when the user asks to transmit it.",
    { path: z.string().min(1).max(200), data: z.string().max(2000) },
    async ({path:portPath,data}) => {
      const s=serialSessions.get(portPath);
      if(!s) return result({success:false,error:"Port is not open."});
      try {
        await new Promise((resolve,reject)=>s.port.write(data,err=>err?reject(err):resolve()));
        return result({success:true,bytes:data.length});
      } catch(e) { return result({success:false,error:String(e.message)}); }
    });

  mcp.tool("serial_close",
    "Close an open serial session.",
    { path: z.string().min(1).max(200) },
    async ({path:portPath}) => {
      const s=serialSessions.get(portPath);
      if(!s) return result({success:false,error:"Port is not open."});
      try {
        await new Promise((resolve,reject)=>s.port.close(err=>err?reject(err):resolve()));
        serialSessions.delete(portPath);
        return result({success:true,path:portPath,closed:true});
      } catch(e) { return result({success:false,error:String(e.message)}); }
    });

  return mcp;
}

app.get("/health",(_req,res)=>res.json({ok:true,name:"Arduino Engineering MCP",version:"1.2.0",tools:14}));
app.all("/mcp",async(req,res)=>{
  if(!authorized(req)) return res.status(401).json({error:"Unauthorized. Configure MCP_API_TOKEN."});
  const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined});
  const server=buildMcp();
  res.on("close",()=>{transport.close();server.close();});
  try { await server.connect(transport); await transport.handleRequest(req,res,req.body); }
  catch(e){ console.error("MCP request failed",e); if(!res.headersSent)res.status(500).json({error:"MCP request failed."}); }
});

app.listen(PORT,"0.0.0.0",()=>console.log(`AEMCP v1.2 listening on ${PORT}`));
