# Arduino Engineering MCP — GitHub Automated v1.1

## What happens after upload?
On pushes to `main` or `master`, GitHub Actions installs dependencies, checks syntax, runs tests, builds the Docker image and publishes it to GitHub Container Registry (GHCR). An optional Render deploy-hook job runs when repository variable `RENDER_DEPLOY_ENABLED=true` and secret `RENDER_DEPLOY_HOOK_URL` are configured. Pull requests run validation only.

## One-time hosting setup
GitHub cannot create a hosting account or accept provider terms for you.

1. Create a GitHub repository.
2. Extract this ZIP directly into the repository root. Keep the hidden `.github` folder.
3. Commit and push to `main`.
4. In Render, choose **New → Blueprint** and select the repository. Render reads `render.yaml`.
5. Set `MCP_API_TOKEN` in the Render service environment to a long random secret.
6. Deploy and check `https://YOUR-SERVICE.onrender.com/health`.
7. Render has `autoDeploy: true`, so future pushes can deploy automatically.

Optional: create a Render deploy hook and add repository secret `RENDER_DEPLOY_HOOK_URL` plus repository variable `RENDER_DEPLOY_ENABLED=true`. Do not enable both auto-deploy and the hook unless duplicate deploy triggers are intentional.

## Claude Android
Use Claude Web with the same account: Settings → Connectors → Add custom connector. MCP URL:
`https://YOUR-SERVICE.onrender.com/mcp`

This server uses `Authorization: Bearer <MCP_API_TOKEN>`. Confirm Claude's connector setup supports that authentication. If not, put an OAuth-compatible authentication proxy in front; do not remove authentication from a public service.

## Tools
`analyze_arduino_sketch`, `validate_arduino_wiring`, `list_supported_boards`, `compile_arduino_sketch`, `install_arduino_library`, `list_installed_arduino_libraries`, `run_wokwi_simulation`, `analyze_serial_log`, `list_serial_ports`, `serial_open`, `serial_read`, `serial_send`, `serial_close`.

## Limitations
- This is source code, not a deployed or live-tested Claude service.
- Docker installs Arduino CLI and AVR core. ESP32 compilation needs the Espressif core installed separately.
- Wokwi needs its CLI, authentication and a valid project directory on the server.
- Serial tools only see devices visible to the server machine/container. A cloud server cannot access a phone's OTG-connected Arduino; physical hardware needs a local agent on the computer connected to the board.
- Static checks cannot certify wiring, voltage, current or electrical safety.
- Tests check repository structure/tool declarations, not real hardware or end-to-end Claude behaviour.

## Local checks
```bash
npm install
npm run check
npm test
```
Set `NODE_ENV=production` and a strong `MCP_API_TOKEN` for public deployment. Never commit secrets.
