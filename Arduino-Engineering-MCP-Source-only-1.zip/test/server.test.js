import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

test("all advertised MCP tools are present", () => {
  const source = fs.readFileSync(new URL("../src/server.js", import.meta.url), "utf8");
  for (const name of [
    "analyze_arduino_sketch","validate_arduino_wiring","list_supported_boards",
    "compile_arduino_sketch","install_arduino_library","list_installed_arduino_libraries",
    "run_wokwi_simulation","analyze_serial_log","list_serial_ports",
    "serial_open","serial_read","serial_send","serial_close"
  ]) assert.ok(source.includes(`"${name}"`), `Missing ${name}`);
});

test("health and MCP endpoints exist", () => {
  const source = fs.readFileSync(new URL("../src/server.js", import.meta.url), "utf8");
  assert.match(source, /app\.get\("\/health"/);
  assert.match(source, /app\.all\("\/mcp"/);
});

test("production mode refuses requests without a configured token", () => {
  const source = fs.readFileSync(new URL("../src/server.js", import.meta.url), "utf8");
  assert.match(source, /if \(!TOKEN\) return process\.env\.NODE_ENV !== "production"/);
});
